﻿using System;
using System.Collections.Generic;
using System.Text;


namespace LargestPalindromeNDigits
{
    public class Palindromes
    {

        //This could potentially take a long time if the number of digits was really high and currently time complexity is not the greatest, 
        //I'd love some suggestions to make it more efficient, currently time complexity is n^2
        public int GetLargestProductPalindrome(int numberOfDigits)
        {
            Objects.Palindrome palindrome = new Objects.Palindrome(numberOfDigits);

            for (int firstNumber = GetLargestPossibleNumber(numberOfDigits); firstNumber > GetLargestPossibleNumber(numberOfDigits - 1); firstNumber--)
            {
                for (int secondNumber = GetLargestPossibleNumber(numberOfDigits); secondNumber > GetLargestPossibleNumber(numberOfDigits - 1); secondNumber--)
                {
                    if (isAPalindrome(firstNumber * secondNumber) && (firstNumber * secondNumber) > palindrome.LargestPalindrome)
                    {
                        palindrome.LargestPalindrome = firstNumber * secondNumber;
                    }
                }
            }

            return palindrome.LargestPalindrome;
        }

        public int GetLargestPossibleNumber(int numberOfDigits)
        {

            return (int)Math.Pow(10, numberOfDigits) - 1;
        }

        public bool isAPalindrome(int number)
        {

            int remainder;
            int sum = 0;
            int original;

            original = number;

            while (number > 0)
            {
                remainder = number % 10;
                sum = (sum * 10) + remainder;
                number = number / 10;
            }

            if (original == sum)
                return true;
            else
                return false;

        }


    }
}
