﻿using System;

namespace Objects
{
    public class Palindrome
    {

        public Palindrome(int numberOfProductDigits)
        {
            this.NumberOfDigits = numberOfProductDigits;
        }
        public int NumberOfDigits { get; set; }
        public int LargestPalindrome { get; set; }
        public string PalindromeString { get; set; }
    }
}
