﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestSuite
{

    [TestFixture]
    class UnitTests
    {
      
        //this was the test case given to us on the website
        [TestCase]
        public void GetLargestProductPalindrome()
        {
            LargestPalindromeNDigits.Palindromes palindromeLogic = new LargestPalindromeNDigits.Palindromes();
            Objects.Palindrome palindrome = new Objects.Palindrome(3);
            Assert.AreEqual(9009, palindromeLogic.GetLargestProductPalindrome(palindrome.NumberOfDigits));
        }
    }
}
