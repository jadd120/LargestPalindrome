﻿using System;

namespace Content
{
    class Program
    {
        public static void Main(string[] args)
        {
            LargestPalindromeNDigits.Palindromes palindromeLogic = new LargestPalindromeNDigits.Palindromes();
            
            Console.WriteLine("Please enter the number of digits of the product factors:");
            Objects.Palindrome palindrome = new Objects.Palindrome(Convert.ToInt32(Console.ReadLine()));

            palindrome.LargestPalindrome = palindromeLogic.GetLargestProductPalindrome(palindrome.NumberOfDigits);

            Console.WriteLine("The largest possible palindrome is: " + palindrome.LargestPalindrome.ToString());


        }
    }
}
